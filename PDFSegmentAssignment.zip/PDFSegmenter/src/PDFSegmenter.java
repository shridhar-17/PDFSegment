import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.TextPosition;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;

public class PDFSegmenter {

    private static class TextBlock {
        float startY;
        float endY;
        String text;

        TextBlock(float startY, float endY, String text) {
            this.startY = startY;
            this.endY = endY;
            this.text = text;
        }
    }

    private static class PDFTextPositionStripper extends PDFTextStripper {
        private final List<TextBlock> textBlocks = new ArrayList<>();
        private float previousY = -1;
        private StringBuilder currentTextBlock = new StringBuilder();

        public PDFTextPositionStripper() throws IOException {
            super.setSortByPosition(true);
        }

        @Override
        protected void writePageStart() {
         }

        @Override
        protected void writePage() {
         }

        @Override
        protected void writePageEnd() {
        }

        @Override
        protected void processTextPosition(TextPosition text) {
            float currentY = text.getYDirAdj();

          if (previousY != -1 && Math.abs(currentY - previousY) > 10) { 
                textBlocks.add(new TextBlock(previousY, currentY, currentTextBlock.toString()));
                currentTextBlock = new StringBuilder();
            }

            currentTextBlock.append(text.getUnicode());
            previousY = currentY;
        }

        public List<TextBlock> getTextBlocks() {
            return textBlocks;
        }
    }

    public static void segmentPDF(String inputFile, int numberOfCuts) throws IOException {
        PDDocument document = PDDocument.load(new File(inputFile));
        PDFTextPositionStripper stripper = new PDFTextPositionStripper();

        for (PDPage page : document.getPages()) {
            stripper.processPage(page); 
        }

        List<TextBlock> textBlocks = stripper.getTextBlocks();

       
             textBlocks.sort(new Comparator<TextBlock>() {
    @Override
    public int compare(TextBlock tb1, TextBlock tb2) {
        return Float.compare(tb1.startY, tb2.startY);
    }
});

       
        List<Float> gaps = new ArrayList<>();
        for (int i = 1; i < textBlocks.size(); i++) {
            float gap = textBlocks.get(i).startY - textBlocks.get(i - 1).endY;
            gaps.add(gap);
        }

        
        List<Float> largestGaps = new ArrayList<>(gaps);
        Collections.sort(largestGaps, Collections.reverseOrder());

        List<Float> cutPoints = largestGaps.subList(0, Math.min(numberOfCuts, largestGaps.size()));

       
        generatePDFSegments(document, textBlocks, cutPoints);

        document.close();
    }
   
  private static void generatePDFSegments(PDDocument document, List<TextBlock> textBlocks, List<Float> cutPoints) throws IOException {
    int segmentCounter = 1;
    PDDocument newSegment = new PDDocument();
    PDPage newPage = new PDPage();
    newSegment.addPage(newPage);
    PDPageContentStream contentStream = new PDPageContentStream(newSegment, newPage);
    
    
    contentStream.setFont(PDType1Font.HELVETICA, 12);

    
    float startY = newPage.getMediaBox().getHeight() - 50; 
    float lineHeight = 15;  

    
    boolean contentAdded = false;

    for (TextBlock block : textBlocks) {
      
        if (!cutPoints.isEmpty() && block.startY >= cutPoints.get(0)) {
            if (contentAdded) { 
                contentStream.close();  
                newSegment.save("segment_" + segmentCounter + ".pdf");
                newSegment.close();
                System.out.println("Saved: segment_" + segmentCounter + ".pdf");
                segmentCounter++;
            }

           
            newSegment = new PDDocument();
            newPage = new PDPage();
            newSegment.addPage(newPage);
            contentStream = new PDPageContentStream(newSegment, newPage);
            contentStream.setFont(PDType1Font.HELVETICA, 12); 

         
            startY = newPage.getMediaBox().getHeight() - 50;
            cutPoints.remove(0); 
            contentAdded = false; 
         }

      
        contentStream.beginText();
        contentStream.newLineAtOffset(100, startY);  
        contentStream.showText(block.text.trim());
        contentStream.endText();

       
        startY -= lineHeight;

        contentAdded = true;  
    }

    
    if (contentAdded) {
        contentStream.close();  
        newSegment.save("segment_" + segmentCounter + ".pdf");
        newSegment.close();
        System.out.println("Saved: segment_" + segmentCounter + ".pdf");
    }
}


    public static void main(String[] args) throws IOException {
        if (args.length != 2) {
            System.out.println("Usage: PDFSegmenter <input-pdf-file> <number-of-cuts>");
            return;
        }

        String inputFile = args[0];
        int numberOfCuts = Integer.parseInt(args[1]);

        segmentPDF(inputFile, numberOfCuts);
    }
}
